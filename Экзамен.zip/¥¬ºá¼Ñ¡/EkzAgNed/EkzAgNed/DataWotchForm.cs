﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EkzAgNed
{
    //public static class Data
    //{
    //    public static int Id = 0;
    //}

    public partial class DataWotchForm : Form
    {
        private void LoadDataInDataGrid()
        {
            try
            {
                using (var db = new pubsEntities())
                {
                    dataGridView.DataSource = db.Киент.ToList();
                }
                dataGridView.Columns[0].Visible = false;
            }
            catch
            {
                MessageBox.Show("Ошибка загрузки данных из базы.");
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadDataInDataGrid();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void buttonRefrash_Click(object sender, EventArgs e)
        {
            try
            {
                LoadDataInDataGrid();
            }
            catch { }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //Data.Id = int.Parse(dataGridView.SelectedCells[0].Value.ToString());
                var form = new AddDataForm();
                form.ShowDialog();
            }
            catch { }
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            try
            {
                using (var db = new pubsEntities())
                {
                    var id = int.Parse(dataGridView.SelectedCells[0].Value.ToString());
                    var record = db.Киент.FirstOrDefault(item => item.ID == id);
                    db.Киент.Remove(record);
                    db.SaveChanges();
                    LoadDataInDataGrid();
                }
            }
            catch { }
        }

        public DataWotchForm()
        {
            InitializeComponent();
        }
    }
}
