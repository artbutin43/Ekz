﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace EkzAgNed
{
    public partial class AddDataForm : Form
    {
        private void AddDataForm_Load(object sender, EventArgs e)
        {
            try
            {
                using (var db = new pubsEntities())
                {
                    if (Data.editMod == 1)
                    {
                        var record = db.Киент.FirstOrDefault(item => item.ID == Data.Id);
                        textBoxFirstName.Text = record.Имя.ToString();
                        textBoxLastName.Text = record.Отчество.ToString();
                        textBoxMiddleName.Text = record.Фамилия.ToString();
                        textBoxPhone.Text = record.НомерТеефона.ToString();
                        textBoxEmail.Text = record.ЭлПочта.ToString();
                    }
                }
            }
            catch { }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var dialogResult = MessageBox.Show("Вы точно хотите внести изменения", "Внимание", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    if ((textBoxPhone.Text.Length > 0 && textBoxPhone.Text != "") ||
                        (textBoxEmail.Text.Length > 0 && textBoxEmail.Text != ""))
                    {

                        using (var db = new pubsEntities())
                        {
                            if (Data.editMod == 0)
                            {
                                Киент киент = new Киент
                                {
                                    Имя = textBoxFirstName.Text,
                                    Фамилия = textBoxMiddleName.Text,
                                    Отчество = textBoxLastName.Text,
                                    НомерТеефона = textBoxPhone.Text,
                                    ЭлПочта = textBoxEmail.Text
                                };
                                db.Киент.Add(киент);
                                db.SaveChanges();
                            }
                            if (Data.editMod == 1)
                            {
                                var record = db.Киент.FirstOrDefault(item => item.ID == Data.Id);
                                record.Имя = textBoxFirstName.Text;
                                record.Отчество = textBoxLastName.Text;
                                record.Фамилия = textBoxMiddleName.Text;
                                record.НомерТеефона = textBoxPhone.Text;
                                record.ЭлПочта = textBoxEmail.Text;
                                db.SaveChanges();
                            }
                        }
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Не заполнены обязатеьные поля");
                    }
                }
            }
            catch { }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxFirstName.Text = "";
                textBoxLastName.Text = "";
                textBoxMiddleName.Text = "";
                textBoxPhone.Text = "";
                textBoxEmail.Text = "";
            }
            catch { }
        }

        public AddDataForm()
        {
            InitializeComponent();
        }
    }

    public class ForTests 
    {
        public int a = 0;
        public int b = 0;
        public int c = 0;

        public int Sum(int a, int b)
        {
            return c = a + b;
        }

        public int Sum2(int a, int b)
        {
            return c = a - b;
        }

        public int Sum3(int a, int b)
        {
            return c = a + b;
        }

        public bool Lenght(string str)
        {
            if (str.Length > 1)
            {
                return true;
            }
            return false;
        }
    }
}
