﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace EkzAgNed
{
    public partial class MainForm : Form
    {
        private void LoadDataInDataGrid()
        {
            try
            {
                using (var db = new pubsEntities())
                {
                    dataGridView.DataSource = db.Киент.ToList();
                }
                dataGridView.Columns[0].Visible = false;
            }
            catch
            {
                MessageBox.Show("Ошибка загрузки данных из базы.");
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadDataInDataGrid();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void buttonRefrash_Click(object sender, EventArgs e)
        {
            try
            {
                LoadDataInDataGrid();
            }
            catch { }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Data.editMod = 0;
                var form = new AddDataForm();
                form.ShowDialog();
                LoadDataInDataGrid();
            }
            catch { }
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            try
            {
                var dialogResult = MessageBox.Show("Вы точно хотите удалить данные", "Внимание", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    using (var db = new pubsEntities())
                    {
                        var id = int.Parse(dataGridView.SelectedCells[0].Value.ToString());
                        var record = db.Киент.FirstOrDefault(item => item.ID == id);
                        db.Киент.Remove(record);
                        db.SaveChanges();
                        LoadDataInDataGrid();
                    }
                }
            }
            catch { }
        }

        private void buttonRename_Click(object sender, EventArgs e)
        {
            try
            {
                Data.editMod = 1;
                Data.Id = int.Parse(dataGridView.SelectedCells[0].Value.ToString());
                var form = new AddDataForm();
                form.ShowDialog();
                LoadDataInDataGrid();
            }
            catch { }
        }

        public MainForm()
        {
            InitializeComponent();
        }
    }
}
