﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using EkzAgNed;

namespace EkzAgNedTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var forTests = new ForTests();
            int ex = forTests.Sum(5, 4);
            Assert.AreEqual(ex, 9);
        }

        [TestMethod]
        public void TestMethod3()
        {
            var forTests = new ForTests();
            int ex = forTests.Sum2(5, 4);
            Assert.AreEqual(ex, 9);
        }

        [TestMethod]
        public void TestMethod4()
        {
            var forTests = new ForTests();
            int ex = forTests.Sum3(5, 4);
            Assert.AreEqual(ex, 9);
        }

        [TestMethod]
        public void TestMethod2()
        {
            var forTests = new ForTests();
            bool ex = forTests.Lenght("");
            Assert.AreEqual(ex, true);
        }
    }
}
